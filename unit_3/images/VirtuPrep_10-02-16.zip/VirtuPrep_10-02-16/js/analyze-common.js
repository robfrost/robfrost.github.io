$(document).ready(function () {

    // Bootstrap Datapicker
    if($( "#date-second, #date-first").length) {
        $( "#date-second, #date-first" ).datepicker();
    }

    // Change Charts
    $('.chart-item').not(':first').hide();
    $('.charts .tab').on('click', function(){
        $('.charts .tab').removeClass('active').eq($(this).index()).addClass('active');
        $('.chart-item').hide().eq($(this).index()).fadeIn();
    }).eq(0).addClass('active');

    // Chart REFRESH
    $(window).on('resize', function() {
        chartHeight();
    });
    $('.chart-refresh').on('click', function(){
        chartHeight();
    });
    $('.highcharts-axis-labels').on('click', function(){
        widget();
    })
    chartHeight();

}); // -> ready_END;
