$(document).ready(function(){

    $('.content-output').focus();

    // VIRTUAL-KEYBOARD
    $('.customKeyboard').on('focus', function(){
        if(!$(this).siblings().hasClass('keyboard_wrapper')){
            $(this).customKeyboard();
            keyboardPosition(this);
        }
        $(this).keyup(function(){
            keyboardPosition(this);
        });
    });

    // POPUP
    $('.showPopup').on('click', function(){
        var target = $(this).attr('target-popup'),
            popupContent = $(target).children();
        $(target).fadeIn().find('.content-output').focus();
        verticalALign(target);
        $(window).on('resize', function(){
            setTimeout(function(){
                verticalALign(target);
            }, 0);
        });
    });
// Vertical-align for POPUP
    function verticalALign (selector) {
        var obj = $(selector),
            parentH = obj.outerHeight(),
            childH = obj.children().outerHeight(),
            offsetTop = (parentH - childH) / 2;
        obj.children().css({top : offsetTop});
    }

    // POPUP - HERO
    $('.demo-popup .form-control').on('keypress', function(){
        var offsetTop = $(this).offset().top,
            hero = $(this).closest('.demo-popup').find('.hero'),
            parent = $(this).closest('.form-horizontal');

        var parentHeight = parent.outerHeight(),
            heroHeight = hero.outerHeight(),
            margin = offsetTop - heroHeight - 67,
            maxMargin = parentHeight - heroHeight - 20;

        if ( margin < -1 ) {
            hero.animate({'top': 0 + 'px'});
        } else if (parentHeight < (margin + heroHeight) ) {
            hero.animate({'top': maxMargin + 'px'});
        } else {
            hero.animate({'top': margin + 'px'});
        }
        $('button.popup-close , .popup').on('click', function(){
            // Hero position re-open popup
            $('.hero').animate({'top': 0 + 'px'});
        });
    });

}); // -> ready_END;
