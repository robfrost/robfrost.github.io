(function ( $ ) {

    $.fn.tableEdit = function() {

            var checklist = $('.table-edit');

            function listener () {
                var items = checklist.find('tr td'),
                    inputs = items.find('input');

                for ( var i = 0; i < items.length; i++) {
                    $(items[i]).on('dblclick', editItem);
                    $(inputs[i]).on('blur', updateItem);
                    $(inputs[i]).on('keypress', itemKeypress);
                }
            }

            function editItem () {
                var input = this.querySelector('input');
                if( !!input ) {
                    $(this).addClass('edit');
                    input.setAttribute('size', input.value.length + 1);
                    input.focus();
                    input.setSelectionRange(0, input.value.length);
                }
            }

            function updateItem () {
                $(this).next().text($(this).val());
                $(this).parent().removeClass('edit');
            }

            function itemKeypress (event) {
                $(this).attr('size', $(this).val().length + 1);
                if(event.which === 13) {
                    updateItem.call($(this));
                }
            }

            $('#new-group').on('click', function(){
                var row = checklist.find('tr').first().clone(),
                    firstCell = row.find('td').first();
                row.find('span').empty();
                row.find('input').val('');
                checklist.append(row);
                listener ();
                editItem.call(firstCell[0]);
            });

            listener ();
    };

}( jQuery ));