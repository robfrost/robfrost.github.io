$(document).ready(function () {

    function detectStrSpace (id) {
        var parent = $(id).find('.content-output'),
            contentHeight = parent.prop('scrollHeight'),
            lineHeight = $('.content-output').css('lineHeight'),
            lineHeight = parseInt(lineHeight),
            ratio = (contentHeight / lineHeight) / 5;
            ratio = Math.round(ratio);

        function createPoints () {
            parent.find('.marker-wrapper').remove();
            var wrap = document.createElement('div');
            wrap.className = 'marker-wrapper'
            $(parent).append(wrap);

            for(var i = 0; i < ratio; i++) {
                var int = document.createElement('div');
                int.innerHTML = i * 5;
                int.className = 'marker-counter';
                int.style.top = ((lineHeight * 5) * i) - lineHeight + 'px';
                if( i != 0) {
                    $(parent).find('.marker-wrapper').append(int);
                }
            }
        }

        createPoints ();
    } // -> END Detect Str Space

    var modalBtns = $('.modal-buttons button');
    if(modalBtns.length) {
        modalBtns.on('click', function(){
            var attr = $(this).attr('target-popup');
            setTimeout(function(){
                detectStrSpace(attr);
            }, 500);
            $(window).on('resize', function(){
                detectStrSpace(attr);
            });
        });

    }


    $('.dropdown').hover(function() {
        $(this).toggleClass('open');
    });

    // HEADER SIZE
    function heightDetect() {
        var windowH = $(window).height();
        $('header.top-head').css({
            height : windowH
        });
    }
    heightDetect();

    $(window).resize(function () {
        var footer = $("#to-footer");
        if (footer.hasClass('disabled')) {
            var headerHeight = $('.top-navigation nav').outerHeight(),
                height = $(window).height() - headerHeight - footer.outerHeight();
            applyCSS(height);
        } else {
            heightDetect();
        }
    });

    // SCROLL-TO-BOTTOM
    var headerHeight = $('.top-navigation nav').outerHeight(),
        whatIsHeight = $('.what-is').outerHeight();

    $("#to-footer").click(function () {
        if (!$(this).hasClass('animation')) {
            if ($(this).hasClass('trigger-page2')) {
                $(this).removeClass('trigger-page2');
                return scrollToPage1(this);
            } else {
                $(this).removeClass('trigger-page1');
                return scrollToPage2(this);
            }
        }
    });

    $(".page_wrapper").mousewheel(function(event, delta) {
        //delta -1 = down
        //delta 1 = up
        var footer = $("#to-footer");
        if( !$('.showPopup').is(':visible') ) {
            event.preventDefault();
        }
        if (!footer.hasClass('animation') && !$('.popup').is(':visible')) {
            if (delta > 0) {
                if (footer.hasClass('trigger-page2')) {
                    footer.removeClass('trigger-page2');
                    return scrollToPage1(footer);
                }
            } else {
                if (footer.hasClass('trigger-page1')) {
                    footer.removeClass('trigger-page1');
                    return scrollToPage2(footer);
                }
            }
        }
    });

    function scrollToPage1(obj) {
        $(obj).addClass('trigger-page1 animation');
        scrollDiv(obj, 0);
    }

    function scrollToPage2(obj) {
        $(obj).addClass('trigger-page2 animation');
        var offsetTop = $(obj).offset().top,
            top = (offsetTop - headerHeight);
        applyCSS(top);
        scrollDiv(obj, top * -1);
        return false;
    }

    function scrollDiv (obj, top) {
        $("#scrollDiv").css({
            top: top + 'px',
            'transition': '1s'

        });
        setTimeout(function(){
            $(obj).removeClass('animation');
        }, 1100);
        var scrollViewer = $('.scroll-viewer').find('.top-circle');
        if (top < 0) {
            scrollViewer.css('background', '#bed8e0').next().css('background', '#ffde00');
        } else {
            scrollViewer.css('background', '#ffde00').next().css('background', '#bed8e0');
        }
    }

    function applyCSS(top) {
        $('.page2').height(top + 'px');
        var width = top * 1.777777;
        if (width > $(window).width()) {
            width = $(window).width() - 100;
        }
        $('.video-block .placeholder').width(width + 'px');
    }

    // Resize page2
    $(window).resize(function(){
        if ($('#to-footer').hasClass('trigger-page2')){
            var windowH = $(window).height(),
            page2Height = windowH - (headerHeight + whatIsHeight);
            applyCSS(page2Height);
            $("#scrollDiv").stop(true, true).css({
                top: (page2Height  * -1) + 'px',
                'transition': 'none'
            });
        }
    });

    // VIDEO-GALLERY
    $('.placeholder .video-1').mouseenter(function () {
        //displayVideo(this);
    });

    function displayVideo(obj) {
        var parent = $(obj).parent();
        $('.youtube_placeholder').show();
        var video_id = $(parent).attr('rel');
        $("#voice_player_full").attr('src', 'http://www.youtube.com/embed/' + video_id + '?autoplay=1&controls=0&showinfo=0');
    }

    $('.youtube_placeholder').mouseleave(function () {
        $(this).hide();
        $("#voice_player_full").attr('src', '');
        $('.placeholder .video-1').show();
    });


    // POPUP-GIFS
    $('.voice').not(':eq(4)').on('click', function(){
        var target = $(this).attr('rel');
        $('.voice').css('opacity', '0');
        $(target).show();
        $(target).on('click', function(){
            $(this).hide();
            $('.voice').css('opacity', '1');
        });
    });

    $(document).mouseup(function (e){
        var div = $(".video_mask1");
        if (!div.is(e.target) && div.has(e.target).length === 0) {
            div.hide();
        }
    });


    // Hover-effect & transparent bg for POPUP-GIFS
    function voiceHover (obj) {
        var voiceHover = $(obj);
        voiceHover.not(':eq(4)').hover(function(){
            $(this).css({
                'opacity' : '1',
                "-webkit-box-shadow" : "8px 8px 10px #000",
                "-moz-box-shadow" : "8px 8px 10px #000",
                "box-shadow" : "8px 8px 10px #000"
            });
            voiceHover.not(':eq(4)').not(this).css('opacity', '0.5');
        }, function(){
            voiceHover.css({
                'opacity' : '1',
                "-webkit-box-shadow" : "none",
                "-moz-box-shadow" : "none",
                "box-shadow" : "none"
            });
            voiceHover.not(this).removeClass('voice-hover');
        });
    }
    voiceHover(".voice");

    // POPUP
    $('.showPopup').on('click', function(){
        var target = $(this).attr('target-popup'),
            popupContent = $(target).children();
        $(target).fadeIn().find('.content-output').focus();
        verticalALign(target);
        //scale(popupContent);
        scrollBlock (target);
        $(window).on('resize', function(){
            //scale(popupContent);
            verticalALign(target);
        });
        popupContent.find('button.popup-close').on('click', function(){
            $(target).fadeOut();
        });
        $(target).not('#registration').on('click', function(){
            $('.popup').fadeOut();
        });
        popupContent.on('click', function(e){
            e.stopPropagation();
        });
    });


    // Vertical-align for POPUP
    function verticalALign (selector) {
        var obj = $(selector),
            parentH = obj.outerHeight(),
            childH = obj.children().outerHeight(),
            offsetTop = (parentH - childH) / 2;
        obj.children().css({top : offsetTop});
    }

    // SCALE
    function scale (selector) {
        var obj = $(selector),
            bodyWidth = $('body').outerWidth(),
            bodyHeight = $('body').outerHeight(),
            bodyHeight = $('body').outerHeight();
            scaleMin = Math.min(bodyWidth / 1000, bodyHeight / 1000);
        obj.css({
            "-webkit-transform" : "scale(" + scaleMin + ")",
            "-moz-transform" : "scale(" + scaleMin + ")",
            "-ms-transform" : "scale(" + scaleMin + ")",
            "-o-transform" : "scale(" + scaleMin + ")",
            "transform" : "scale(" + scaleMin + ")"
        });
    }

    // Scroll-block
    function scrollBlock (selector) {
        var scrollBlock = $(selector).find('.scroll-block'),
            scrollBlockHeight = scrollBlock.outerHeight();

        scrollBlock.css({
            "maxHeight" : scrollBlockHeight,
            'overflow-y': 'auto'

        });
        $('button.popup-close , .popup').on('click', function(){
            scrollBlock.css({
                "maxHeight" : 'auto',
                'overflow-y': 'hidden'
            });
        });
    }
    // CustomScrollBar
    $('.scroll-block').mCustomScrollbar({
        theme: 'light-thick',
        scrollButtons:{ enable: true }
    });

    // ADD-BUTTONS for Create Pop-up
    var alphabet = ['e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
    $('#add-answer').on('click', function(){
        var shifted = alphabet.shift();
        var answer = '<div class="form-inline open-keyboard mb-5"> <div class="inline-checkbox fn-w100-mob"> <label>' + shifted + ' - <input type="checkbox"> </div></label>  <div class="form-control fn-w100-mob customKeyboard" id="" contenteditable="true">When did The Vietnam War begin?</div> </div> ';
        $(this).parent().before(answer);
    });

    $('#add-explanation').on('click', function(){
        var explanation = '<div class="explanation-inline open-keyboard mb-5"> <label for="" class="fn-w100">Explanation </label> <div class="form-control fn-w100 customKeyboard" id="" contenteditable="true">When did The Vietnam War begin?</div> </div>';
        $(this).parent().before(explanation);
    });


    // VIRTUAL-KEYBOARD
    $('.customKeyboard').on('focus', function(){
        if(!$(this).siblings().hasClass('keyboard_wrapper')){
            $(this).customKeyboard();
            keyboardPosition(this);
        }
        $(this).keyup(function(){
            keyboardPosition(this);
        });
    });


    // POPUP - HERO
    $('.demo-popup .popup-body .form-control').on('keypress', function(){
        var offsetTop = $(this).offset().top,
            hero = $(this).closest('.popup-body').find('.hero'),
            parent = $(this).closest('.form-horizontal');

        var parentHeight = parent.outerHeight() - 55,
            heroHeight = hero.outerHeight(),
            margin = offsetTop - heroHeight - 10,
            maxMargin = parentHeight - heroHeight;
        if ( margin < -1 ) {
            hero.animate({'top': 0 + 'px'});
        } else if (parentHeight < (margin + heroHeight) ) {
            hero.animate({'top': maxMargin + 'px'});
        } else {
            hero.animate({'top': margin + 'px'});
        }
        $('button.popup-close , .popup').on('click', function(){
            // Hero position re-open popup
            $('.hero').animate({'top': 0 + 'px'});
        });
    });


    // Dropdown-language
    $(".dropdown dt a").click(function() {
        $(".dropdown dd ul").toggle();
    });
    $(".dropdown dd ul li a").click(function() {
        var caret = $('.caret');
        var text = $(this).html();
        $(".dropdown dt a span").html(text);
        $(".dropdown dd ul").hide();
        $("#result").html("Selected value is: " + getSelectedValue("sample"));
    });
    function getSelectedValue(id) {
        return $("#" + id).find("dt a span.value").html();
    }
    $(document).bind('click', function(e) {
        var $clicked = $(e.target);
        if (! $clicked.parents().hasClass("dropdown"))
            $(".dropdown dd ul").hide();
    });
}); // -> ready_END;