$(document).ready(function(){

    // ADD-BUTTONS for Create Pop-up
    var alphabet = ['c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'];
    $('body').on('click', '#add-answer', function(){
        var shifted = alphabet.shift();
        var answer = '<div class="form-inline open-keyboard mb-5"> <div class="inline-checkbox fn-w100-mob"> <label><input type="checkbox"> ' + shifted  + '  )</div></label>  <div class="form-control fn-w100-mob customKeyboard" id="" contenteditable="true">When did The Vietnam War begin?</div> </div> ';
        $('.create').find('form .mCSB_container').append(answer);
        columnHeight();
    });

    $('body').on('click', '#add-explanation', function(){
        var explanation = '<div class="explanation-inline open-keyboard mb-5"> <label for="" class="fn-w100">Explanation </label> <div class="form-control fn-w100 customKeyboard" id="" contenteditable="true">When did The Vietnam War begin?</div> </div>';
        $('.create').find('form .mCSB_container').append(explanation);
        columnHeight();
    });

    $('body').on('click', '#add-attribution', function(){
       var attribution = '<div class="attribution"><span class="attribution-name">1: Jack Mellon, The Book of Light, 3.5.2015, </span> <span class="attribution-link"><a href="#"> www.bookoflight.com</a></span> </div>';
        $('.signature').append(attribution);
        columnHeight();
    });

    $('.reference-resize').resizable({
        handles:'s',
        minHeight: 139
    });


    /* Groups Page SCRIPTS
    ---------------------- */

    // AUTOCOMPLITE
    var availableTags = [
        'B.James',
        'B.Jamison',
        'B.James Jr.',
        'B.James Christopher'
    ];

    // jQuery-UI Autocomplete
    $(".groups-search").autocomplete({
        source: availableTags
    });

    // Remove current table-cell
    $('.groups-panel table tbody tr').hover(function(){
        var btn = '<button class="hover-close-btn"></button>';
       $(this).find('td:last-child').append(btn);
    }, function(){
        $(this).find('td:last-child').find('.hover-close-btn').remove();
    });
    $('body').on('click','.hover-close-btn', function(){
        $(this).closest('tr').remove();
    });

    // Fix for Choosen-plugin
    setTimeout(function(){
        if( $('#tableForGroup').outerHeight() < $('.dataTables_wrapper').outerHeight() ) {
            $('#mCSB_3_container').height('100%');
        }
    },0)


}); // -> ready_END;