$(document).ready(function(){

    // CustomScrollBar
    $('.custom-scroll').mCustomScrollbar({
        theme: 'light-thick',
        scrollButtons:{ enable: true },
        callbacks: {
            onScrollStart: function(){
                if(!$('.inside-folder').is(':visible')) {
                    $('.editIcons').hide();
                }
                $('.select-users').find('.tooltip-info').removeClass('open');
            }
        }
    });

    // Progress Bar
    function progressBar () {
        var bar = $('.progress-bar');
        bar.each(function(){
            var progress = $(this).attr('progress'),
                progressline = $(this).find('.progress-bar-w');
            progressline.width(progress + '%');
        });
    };

    // Same Column Height
    function sameColumn () {
        $('.sameCol-wrap').each(function(){
            var currentColumns = $(this).find('.sameCol');
            sameColumnHeight.call( currentColumns ) ;
        });
    }
    function sameColumnHeight () {
        var tallestColumn = 0;
        $(this).height('auto');
        $(this).each(function () {
            if (tallestColumn < $(this).outerHeight()) {
                tallestColumn = $(this).outerHeight();
            }
        });
        $(this).height(tallestColumn);
    }

    // Image Size
    function detectImage () {
        var image = $('._image-align');

        image.each(function(){
            var wrapper = $(this).parent();
            wrapper.css({ 'position': 'relative', 'overflow': 'hidden' });
            imageSize (image, wrapper);
            $(window).on('resize', function(){
                imageSize (image, wrapper);
            });
        });

    }
    function imageSize (image, wrapper) {
        if( wrapper.width() < wrapper.height() ) {
            image.removeClass('_image-align');
            image.addClass('_image-align_height');
        } else {
            image.removeClass('_image-align_height');
            image.addClass('_image-align');
        }
    }

    // User List Tooltip
    if( $('.select-users').length ) {
        tooltipInfo();
    }

    // Trigger Btn on Home Page
    if($('.trigger-btn').length) {
        $('.trigger-btn').on('click', function(){
            var text = $(this).text();
           $(this).toggleClass('trigger-off').text( text == "On" ? "Off" : "On");
        });
    }

    // Subject Btn on Home Page 
    if($('.subject-btn').length) {
        $('.subject-btn').on('click', function(){
            $(this).toggleClass('subject-btn_on');
            $(this).children().toggleClass('hidden');
        });
    }

    // Groups Table EDIT func
    if($('.table-edit').length) {
        $('.table-edit').tableEdit();
    }

    // Invite User ( Groups Page )
    if( $('#show-invite-user-field').length ) {
        var showFieldBtn = $('#show-invite-user-field'),
            inviteUserBtn = $('#invite-user');
        showFieldBtn.on('click', function(){
            $(this).addClass('hidden');
            $(this).next().removeClass('hidden').find('input').focus();
        });
        inviteUserBtn.on('click', function(){
            showFieldBtn.removeClass('hidden');
            $(this).parent().addClass('hidden');
        });
    }


    // Chosen JS Selector Plugin
    if($('.vp-groups-select, .my_select_box').length){
        $('.vp-groups-select, .my_select_box').chosen({
            inherit_select_classes: true,
            width: 200
        });
    }

    // jQuery UI Slider
    if($('.v-slider').length){
        $('.v-slider').each(function(){
            var counter = $(this).next(),
                value = parseInt( counter.text(), 10);
           $(this).slider({
               value: value,
               range: "min",
               orientation: "vertical",
               slide: function( event, ui ) {
                   counter.text(ui.value);
               }
           });
        });
    }

    // Tooltipster Widget view
    if($('.vp-widget-tooltip').length){
        $('.vp-widget-tooltip').tooltipster({
            functionBefore: function(origin,continueTooltip) {
                origin.tooltipster('content', origin);
                continueTooltip();
            }
        });
    }
    // Tooltipster Create Page Btn view
    if($('.answer-btn-msg').length) {
        $('.answer-btn-msg').tooltipster({
            trigger: 'click',
            timer: 250
        });
    }

    // EDIT PERMISSION
    if($('.select-users_create').length){
        $('.select-users_create .scroll-users ul li').each(function(){
            var iconFolder =
                '<div class="permission-edit editIcons">' +
                    '<div class="permission-edit-icons practice-only">Practice Only</div>' +
                    '<div class="permission-edit-icons can-copy">Can Copy</div>' +
                    '<div class="permission-edit-icons no-access">Remove Access</div>' +
                '</div>';
            $(this).append(iconFolder);
        });
        rightClickMenu ('.select-users_create .scroll-users ul li');
    }

    // Toggle user-button
    $('.toggle-user-button').on('click', function(){
        $('.select-users').toggleClass('user-list_close');
        $('.content-panel').parent().toggleClass('full-screen');
        if (document.querySelector('.vp-horizontal-scroll')) {
            tableScroll();
        }
    });

    //  Resize Tree jQuery-UI
    $(".tree").resizable({
        handles: "n, e",
        minWidth: 43,
        maxWidth: 650,
        resize: function(){
            if($(this).width() < 60) {
                $(this).addClass('small-buttons');
            } else {
                $(this).removeClass('small-buttons');
            }
            if($(this).width() > 235) {
                $('.top-tree').addClass('tree-btns-huge');
            } else {
                $('.top-tree').removeClass('tree-btns-huge');
            }
        }
    });

    function treeIconsResize () {
        var tree = $('.tree');
        if(tree.width() < 60) {
            tree.addClass('small-buttons');
        } else {
            tree.removeClass('small-buttons');
        }
    }

    // Chart Pie Reflow
    if($('.virtuPrep_chart-pie').length){
        $(".tree").resizable({
            resize: function(){
                $('[class^=virtuPrep_chart]').highcharts().reflow();
            }
        });
        $(window).load(function(){
            $('[class^=virtuPrep_chart]').highcharts().reflow();
        });
    }


    // Function Activated:
    ////////////////////////////////

    if( $('.sameCol-wrap').length ) {
        sameColumn.call( $('.sameCol-wrap') );
    }
    if( $('._image-align').length ) {
        detectImage ();
    }
    if($('.progress-bar').length) {
        progressBar();
    }

    treeIconsResize ();

    // Table Scroll
    setTimeout(function () {
        if ($('.vp-horizontal-scroll').length) {
            tableScroll();
        }
    }, 500);

    // RATING
    if ($('.rating span').length) {
        rating();
    }
    // DROPDOWNS
    if ($('.dropdown').length) {
        dropdown();
    }
    // SELECTS
    if ($('.select-list').length) {
        selectList();
    }
    // Page Height ( must activate at least  )
    columnHeight();
    
    // WINDOW RESIZE
    $(window).on('resize', function () {
        columnHeight();
        treeIconsResize ();
        if ($('.vp-horizontal-scroll').length) {
            tableScroll();
        }
    });

}); // -> ready_END;

/*-------------------------
 ---- Global Functions -----
 -------------------------*/

// PAGE HEIGHT
function columnHeight() {
    var windowH = $(window).height(),
        outerScrollHeight = 0;
    $('.window-scrolling').each(function () {
        $(this).height(windowH - $(this).offset().top - 42);
    });
    $('.max-window-scrolling').each(function () {
        $(this).css('maxHeight', windowH - $(this).offset().top - 42);
    });
    $('.total-window-scrolling').each(function () {
        $(this).css('maxHeight', windowH - $(this).offset().top - 93);
    });
    $('.outer-scroll').each(function(){
        outerScrollHeight += $(this).outerHeight(true);
    });
    setTimeout(function(){
        $('.window-scrolling_outer').each(function () {
            $(this).height(windowH - $(this).offset().top - outerScrollHeight - 20 );
        });
    }, 0);
}

// Select Function
function selectList() {
    var allSelects = $('.select-list');
    allSelects.each(function () {
        var select = $(this),
            list = select.find('ul');
        $('<span>').prependTo(select).text($(this).find('.selected').text());

        select.on('click', 'span', openList);

        function openList () {
            select.toggleClass('open');
            detectPosition (select, list);
            $(window).on('resize', function(){ detectPosition (select, list) });
        }

        list.on('click', 'li', function(){
            select.find('span').text($(this).text());
            select.find('ul li').removeClass('selected');
            $(this).addClass('selected');
            select.removeClass('open');
        });

    });
    hideToggleElements();
}

// DropDown function
function dropdown () {
    var dropdown = $('.dropdown');
    dropdown.on('click', '.dropdown-toggle', function(){
        $(this).parent().toggleClass('open');
    });
    hideToggleElements();
    dropdown.find('ul li a, .btn').on('click', function(){
       //$(this).closest('.dropdown').removeClass('open');
    });
    dropdown.find('.dropdown-menu').on('click', function(e){
        //e.stopPropagation();
    });
}

// Hide not active elements for selects and dropdowns
function hideToggleElements() {
    $('.dropdown .dropdown-toggle, .select-list span').on('click', function(){
        if (!$(this).parent().hasClass('open')) {
            $('.dropdown, .select-list').removeClass('open');
        }
    });
    $('body').on('click', function(e) {
        if ($(e.target).parents().hasClass('open')) {
            return false;
        }
        $('.dropdown, .select-list').removeClass('open');
    });
}


// User List Tooltop Info
function tooltipInfo () {
    var parent = $('.select-users'),
        users = parent.find('.scroll-users li'),
        tooltip = parent.find('.tooltip-info');

    users.on('mouseenter', function(){
        var self = $(this),
            tooltipHeight = tooltip.outerHeight(),
            scrollBar = parent.find('.mCSB_scrollTools_vertical'),
            scrollBarWidth = scrollBar.is(':visible') ? scrollBar.outerWidth() : 0,
            left = self.offset().left + self.outerWidth() + scrollBarWidth + 20,
            top = self.offset().top - ((tooltip.outerHeight() / 2) - (self.outerHeight() / 2));

        if (top + tooltipHeight < $(window).height()) {
            tooltip.css({
                'top': top,
                'bottom': 'auto',
                'left': left
            });
        } else {
            tooltip.css({
                'top': 'auto',
                'bottom': 0,
                'left': left
            });
            tooltip.find('.tooltip-info_triangle');
        }
        tooltip.addClass('open');
    }).on('mouseleave', function(){
        tooltip.removeClass('open');
    });
}


// Detect Position
function detectPosition (parent, element) {
    var top = parent.offset().top + parent.outerHeight(),
        left = parent.offset().left,
        width = parent.outerWidth();

    element.css({
        'top':  top,
        'left': left,
        'minWidth': width
    });
}


$('nav').find('.user-image').parent().on('click', function(){

    $(this).toggleClass('open');

});


// Rating Stars
function rating () {
    var rating = $('.rating');

    rating.each(function(){
        var stars = $(this).find('span'),
            dataRating = stars.parent().attr('data-rating');

        for (var i = 0; i < dataRating; i++) {
            $(stars[i]).addClass('active');
        }

        if(!stars.parent().hasClass('no-change')) {
            stars.on('mouseenter', function(){
                for (var i = 0; i < $(this).index() + 1; i++) {
                    $(stars[i]).addClass('hover');
                }
            });
            stars.on('mouseout', function(){
                stars.removeClass('hover');
            });
            stars.on('click', function(){
                var ratingValue = $(this).index() + 1;
                $(this).parent().attr('data-rating', ratingValue);
                stars.removeClass('active');
                for (var i = 0; i < ratingValue; i++) {
                    $(stars[i]).addClass('active');
                }
            });
        }
    })
}

// Table ScrollBar
function tableScroll() {
    $('.vp-horizontal-scroll').each(function () {
        var parent = $(this),
            table = parent.find('table'),
            tableW = table.outerWidth(),
            parentW = parent.outerWidth(true) - (parent.find('#mCSB_3_scrollbar_vertical').is(':visible') ? parent.find('#mCSB_3_scrollbar_vertical').outerWidth(true) + 5 : 0);

        if (!table.siblings().hasClass('table-scrollBar_wrapper'))
            table.before('<div class="table-scrollBar_wrapper"><div class="table-scrollBar"></div></div>');

        var scrollBarWrapper = parent.find('.table-scrollBar_wrapper'),
            scrollBar = scrollBarWrapper.find('.table-scrollBar');

        if (parentW < tableW)
            scrollBarWrapper.fadeIn();
        else
            scrollBarWrapper.fadeOut();

        scrollBar.width(parentW / (tableW / parentW));
        scrollBar.draggable({
            axis: 'x',
            containment: 'parent',
            drag: function (event, ui) {
                table.css({
                    right: ui.position.left > 0 ? ui.position.left * (tableW / parentW) : 0
                })
            }
        });
        table.css('right', 0);
    })
}